import Link from "next/link"
import type { ReactNode } from "react"

interface PromoCTAProps {
  title: string
  subtitle?: string
  buttonText: string
  buttonHref: string
  image: ReactNode
  imagePosition?: "left" | "right"
}

export function PromoCTA({ title, subtitle, buttonText, buttonHref, image, imagePosition = "left" }: PromoCTAProps) {
  const contentSection = (
    <div className="flex flex-col items-center lg:items-start text-center lg:text-left">
      <h2 className="font-serif text-3xl md:text-4xl font-bold italic text-foreground mb-4 text-balance">{title}</h2>
      {subtitle && <p className="text-lg md:text-xl text-muted-foreground italic mb-8">{subtitle}</p>}
      <Link
        href={buttonHref}
        className="inline-block bg-primary text-primary-foreground font-bold uppercase tracking-wide px-8 py-4 rounded-md hover:bg-primary/90 transition-colors"
      >
        {buttonText}
      </Link>
    </div>
  )

  const imageSection = <div className="flex justify-center lg:justify-start">{image}</div>

  return (
    <section className="py-16 px-4 md:px-8 lg:px-16 bg-background">
      <div className="max-w-6xl mx-auto">
        <div
          className={`flex flex-col lg:flex-row items-center gap-12 lg:gap-16 ${imagePosition === "right" ? "lg:flex-row-reverse" : ""}`}
        >
          {imageSection}
          {contentSection}
        </div>
      </div>
    </section>
  )
}
