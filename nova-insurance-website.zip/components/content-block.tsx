"use client"

import { useState } from "react"
import { ChevronDown } from "lucide-react"

interface AccordionItem {
  title: string
  content: string
}

interface ContentBlockProps {
  paragraphs: string[]
  accordionItems?: AccordionItem[]
}

export function ContentBlock({ paragraphs, accordionItems }: ContentBlockProps) {
  const [openIndex, setOpenIndex] = useState<number | null>(0)

  const toggleAccordion = (index: number) => {
    setOpenIndex(openIndex === index ? null : index)
  }

  return (
    <section className="relative">
      {/* Golden diagonal accent on left - continuing from banner */}
      <div
        className="absolute left-0 top-0 w-32 h-full bg-gradient-to-br from-amber-400 to-amber-500"
        style={{
          clipPath: "polygon(0 0, 100% 0, 0 100%)",
        }}
      />

      <div className="max-w-5xl mx-auto px-8 py-12 relative z-10">
        {/* Body text paragraphs */}
        <div className="space-y-6 mb-10">
          {paragraphs.map((paragraph, index) => (
            <p key={index} className="text-foreground leading-relaxed text-base">
              {paragraph}
            </p>
          ))}
        </div>

        {/* Accordion sections */}
        {accordionItems && accordionItems.length > 0 && (
          <div className="space-y-4">
            {accordionItems.map((item, index) => (
              <div key={index} className="bg-muted/50 rounded-sm overflow-hidden">
                <button
                  type="button"
                  onClick={() => toggleAccordion(index)}
                  className="w-full flex items-center justify-between px-6 py-4 text-left hover:bg-muted/70 transition-colors cursor-pointer"
                >
                  <h3 className="text-lg font-bold text-foreground">{item.title}</h3>
                  <ChevronDown
                    className={`w-5 h-5 text-primary transition-transform duration-200 ${
                      openIndex === index ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {openIndex === index && (
                  <>
                    <div className="border-t border-border/50 mx-6" />
                    <div className="px-6 py-4">
                      <p className="text-foreground leading-relaxed text-base">{item.content}</p>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  )
}
