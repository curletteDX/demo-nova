"use client"

import { LayoutGrid, List } from "lucide-react"
import { categories } from "@/lib/blog-data"

interface BlogFiltersProps {
  selectedCategory: string
  onCategoryChange: (category: string) => void
  viewMode: "grid" | "list"
  onViewModeChange: (mode: "grid" | "list") => void
}

export function BlogFilters({ selectedCategory, onCategoryChange, viewMode, onViewModeChange }: BlogFiltersProps) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
      {/* Category Pills */}
      <div className="flex flex-wrap gap-2">
        {categories.map((category) => (
          <button
            key={category}
            type="button"
            onClick={() => onCategoryChange(category)}
            className={`px-4 py-2 text-sm font-medium rounded-sm transition-colors cursor-pointer ${
              selectedCategory === category
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-foreground hover:bg-muted/80"
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* View Mode Toggle */}
      <div className="flex items-center gap-1 bg-muted p-1 rounded-sm">
        <button
          type="button"
          onClick={() => onViewModeChange("grid")}
          className={`p-2 rounded-sm transition-colors cursor-pointer ${
            viewMode === "grid"
              ? "bg-background text-foreground shadow-sm"
              : "text-muted-foreground hover:text-foreground"
          }`}
          aria-label="Grid view"
        >
          <LayoutGrid className="w-4 h-4" />
        </button>
        <button
          type="button"
          onClick={() => onViewModeChange("list")}
          className={`p-2 rounded-sm transition-colors cursor-pointer ${
            viewMode === "list"
              ? "bg-background text-foreground shadow-sm"
              : "text-muted-foreground hover:text-foreground"
          }`}
          aria-label="List view"
        >
          <List className="w-4 h-4" />
        </button>
      </div>
    </div>
  )
}
