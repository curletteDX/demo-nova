import type { ReactNode } from "react"

interface RichTextContentProps {
  children: ReactNode
  showAccent?: boolean
  className?: string
}

export function RichTextContent({ children, showAccent = true, className = "" }: RichTextContentProps) {
  return (
    <section className={`relative bg-white py-12 md:py-16 ${className}`}>
      {/* Golden triangle accent bottom-right */}
      {showAccent && (
        <div
          className="absolute bottom-0 right-0 w-48 h-48 opacity-20 pointer-events-none"
          style={{
            background: "linear-gradient(135deg, transparent 50%, #F5A623 50%)",
          }}
        />
      )}

      <div className="container mx-auto px-4 md:px-8 max-w-5xl relative z-10">
        <div className="prose prose-lg max-w-none">{children}</div>
      </div>
    </section>
  )
}

// Styled components for rich text formatting
export function RichTextHeading({ children }: { children: ReactNode }) {
  return (
    <h2 className="font-serif text-3xl md:text-4xl font-bold italic text-gray-900 mt-10 mb-6 first:mt-0">{children}</h2>
  )
}

export function RichTextParagraph({ children }: { children: ReactNode }) {
  return <p className="text-gray-700 leading-relaxed text-base md:text-lg mb-6">{children}</p>
}

export function RichTextList({ items, ordered = false }: { items: string[]; ordered?: boolean }) {
  const Tag = ordered ? "ol" : "ul"
  return (
    <Tag
      className={`text-gray-700 leading-relaxed text-base md:text-lg mb-6 ml-6 ${ordered ? "list-decimal" : "list-disc"}`}
    >
      {items.map((item, index) => (
        <li key={index} className="mb-2">
          {item}
        </li>
      ))}
    </Tag>
  )
}

export function RichTextLink({ href, children }: { href: string; children: ReactNode }) {
  return (
    <a href={href} className="text-primary hover:text-primary/80 underline font-medium">
      {children}
    </a>
  )
}

export function RichTextStrong({ children }: { children: ReactNode }) {
  return <strong className="font-bold text-gray-900">{children}</strong>
}
