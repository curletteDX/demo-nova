import { Header } from "@/components/navigation/header"
import { HeroBanner } from "@/components/hero-banner"
import { ContentBlock } from "@/components/content-block"

export default function Home() {
  const articleParagraphs = [
    `With the end of the year approaching, many of our calendars will be filled with holiday festivities, including ugly sweaters, food, gatherings, and adult beverages. Like many legal aged-adults, we couldn't bare being at one of these events without something strong to sip on. Could you imagine being around that overly talkative co-worker or that mother-in-law you can't stand without a drink? Absolutely not! Now, I'm a fan of everybody having a good time during the holiday season, but some of you, you know who you are, get a little too excited when you have a few days outside of work and hear the words "open bar".`,
    `Many of you may say, "a hangover for a few days is well worth a great night out." To my under 25 crowd, yes, there will come a day when hangovers last longer than a few hours. Enjoy your youth now! Back to my point, however, if the only consequence of a fun-packed night and maybe an early morning of celebrating is just a hangover, that is a night well done. But unfortunately, too often, people leave these holiday gatherings claiming to be okay to drive when they are anything of the sort. So here are a few things to remember as you enjoy this holiday season.`,
  ]

  const accordionItems = [
    {
      title: "Know Your Limit",
      content: `Do you really want to show up to the office on January 2nd with the feeling that everybody is looking at you? Guess what? They are! Because you decided to take eight shots of tequila and smack your boss on the behind. Sounds ridiculous? What's ridiculous is that the open bar is now banned from all holiday parties because you didn't think the first three shots were enough.`,
    },
  ]

  return (
    <div className="min-h-screen">
      <Header />

      <HeroBanner
        title="Drinking in the New Year"
        author="By Ben Ajayi"
        showQuoteForm={true}
        imageSrc="/champagne-celebration-new-year-party.jpg"
        imageAlt="New Year celebration with champagne"
      />

      <ContentBlock paragraphs={articleParagraphs} accordionItems={accordionItems} />

      <main className="max-w-7xl mx-auto px-4 py-16">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-foreground mb-4">Why Choose Nova Insurance?</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Get the coverage you need at prices you can afford. We offer auto, home, life, and business insurance to
            protect what matters most.
          </p>
        </div>
      </main>
    </div>
  )
}
