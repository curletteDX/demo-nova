import { HeroBanner } from "@/components/hero-banner"
import { CarIcon } from "@/components/icons/car-icon"
import { PartnerLogos } from "@/components/partner-logos"
import { RichTextContent, RichTextHeading, RichTextParagraph } from "@/components/rich-text-content"
import { CoverageBlocks } from "@/components/coverage-blocks"
import { FAQSection } from "@/components/faq-section"
import { StartSaving } from "@/components/start-saving"
import { PromoCTA } from "@/components/promo-cta"
import { BuildingsIcon } from "@/components/icons/buildings-icon"

export const metadata = {
  title: "Auto Insurance - Nova Insurance",
  description: "Find the best rates in auto insurance. Get a free quote today and see how much you can save.",
}

export default function AutoInsurancePage() {
  const coverageBlocks = [
    {
      title: "Uninsured/Underinsured Motorist Coverage",
      description:
        "This coverage will respond to injuries that you or your passengers incur in an accident that is not your fault with an uninsured driver or a driver that does not have enough bodily injury liability coverage to cover the extent of your and your passengers' injuries in an accident. It helps cover medical expenses, lost wages, and other related costs.",
    },
    {
      title: "Physical Damage Protection",
      description:
        "If your car is damaged in an accident, or stolen, vandalized, or damaged by fire or weather, the collision and comprehensive coverages on your policy will pay to repair or replace your vehicle if you have elected to carry these coverages. Each of these coverages has a deductible that you will need to be prepared to pay out-of-pocket before your insurance company responds to the claim.",
    },
    {
      title: "Property Damage Liability Protection",
      description:
        "This type of coverage helps pay for damage you cause to someone else's vehicle or property in an accident. It can include things like cars, fences, buildings, or utility poles. It also covers legal defense costs if you're sued, up to the limits of your policy. Most states require this coverage as part of a minimum auto insurance policy.",
    },
    {
      title: "Medical Expenses",
      description:
        "Medical expense coverage helps pay for medical treatment for you and your passengers after an accident, regardless of who is at fault. This can include hospital visits, surgery, X-rays, and other necessary medical care.",
    },
    {
      title: "Personal Injury Protection",
      description:
        "Personal Injury Protection (PIP) covers medical expenses, lost wages, and other costs for you and your passengers after an accident, regardless of fault. It's required in some states and provides broader coverage than basic medical expense coverage.",
    },
    {
      title: "Bodily Injury Liability",
      description:
        "Bodily injury liability coverage pays for injuries you cause to other people in an accident where you are at fault. It covers medical bills, lost wages, and legal fees if you're sued. Most states require this coverage as part of minimum auto insurance requirements.",
    },
  ]

  const faqItems = [
    {
      question: "Do I have to purchase car insurance for my vehicle?",
      answer:
        "In almost every state in the country, a driver is required to purchase car insurance for a registered vehicle that covers at least bodily injury liability and property damage liability protection. Be sure to check the state requirements where you live to find out how much coverage you are required to carry.",
    },
    {
      question: "What factors affect my auto insurance rates?",
      answer:
        "Several factors can affect your auto insurance rates, including your driving record, age, location, type of vehicle, credit score, coverage levels, and deductible amounts. Insurance companies also consider how much you drive and whether you've had any claims in the past.",
    },
    {
      question: "What is the difference between liability and full coverage?",
      answer:
        "Liability coverage pays for damage you cause to others in an accident, including their medical bills and property damage. Full coverage typically includes liability plus collision and comprehensive coverage, which pays to repair or replace your own vehicle if it's damaged in an accident, stolen, or damaged by other events like weather or vandalism.",
    },
    {
      question: "How can I lower my auto insurance premium?",
      answer:
        "You can lower your premium by maintaining a clean driving record, bundling multiple policies, raising your deductible, asking about available discounts, driving a vehicle with safety features, and comparing quotes from multiple insurers. Many companies offer discounts for good students, safe drivers, and military members.",
    },
    {
      question: "What should I do after a car accident?",
      answer:
        "After an accident, make sure everyone is safe and call 911 if there are injuries. Exchange information with the other driver, take photos of the damage and scene, and file a police report. Contact your insurance company as soon as possible to report the claim and follow their instructions for next steps.",
    },
  ]

  return (
    <main>
      <HeroBanner
        title="Find the Best Rates in Auto Insurance"
        subtitle="Enter your zip code below to get started. See how much you can save by switching today. Let Nova Insurance help keep you protected!"
        showQuoteForm={true}
        icon={<CarIcon className="w-28 h-20 text-gray-800" />}
        imageSrc="/driver-scenic-road-view.jpg"
        imageAlt="Driver's view of scenic road through windshield"
      />

      <PartnerLogos />

      <RichTextContent>
        <RichTextParagraph>
          Auto Insurance is a necessary expense to protect you and your car in an accident. An auto policy will help
          cover the cost of the damages and injuries you cause to another person or their property, as well as the
          damages to your vehicle, and your medical expenses if you have purchased a full-coverage policy. Having the
          right coverage can save you from the financial headache that can follow an accident. Nova Insurance
          understands this and can help you find the right amount of coverage to fit your budget with just a few clicks.
          Contact us for a free quote!
        </RichTextParagraph>

        <RichTextHeading>What is Auto Insurance?</RichTextHeading>
        <RichTextParagraph>
          An auto policy is a contract between a driver and an insurance company that provides financial protection to
          the driver in case of a motor vehicle accident or if the driver's car is damaged. The vehicle owner pays an
          agreed-upon premium to their car insurance carrier so that the carrier will respond after a loss involving the
          insured vehicle and will pay certain expenses based on the coverages you select on the policy.
        </RichTextParagraph>

        <RichTextHeading>How Auto Insurance Works</RichTextHeading>
        <RichTextParagraph>
          Auto insurance protects you and your vehicle against potential losses. Here's what's covered on a car
          insurance policy:
        </RichTextParagraph>
      </RichTextContent>

      <CoverageBlocks sectionTitle="What's Covered" blocks={coverageBlocks} />

      <FAQSection items={faqItems} />

      <StartSaving />

      <PromoCTA
        title="Drop by One of Our Convenient Locations"
        subtitle="and chat with a friendly agent!"
        buttonText="Find a Location Near You!"
        buttonHref="/locations"
        image={<BuildingsIcon className="w-64 h-56 md:w-80 md:h-64" />}
        imagePosition="left"
      />
    </main>
  )
}
