"use client"

import { useState } from "react"
import { Header } from "@/components/navigation/header"
import { HeroBanner } from "@/components/hero-banner"
import { BlogFilters } from "@/components/blog/blog-filters"
import { ArticleCard } from "@/components/blog/article-card"
import { ArticleListItem } from "@/components/blog/article-list-item"
import { blogArticles } from "@/lib/blog-data"

export default function BlogPage() {
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")

  const filteredArticles =
    selectedCategory === "All" ? blogArticles : blogArticles.filter((article) => article.category === selectedCategory)

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <HeroBanner
        title="Nova Insurance Blog"
        subtitle="Expert insights, tips, and advice to help you stay safe on the road and make informed insurance decisions."
        showQuoteForm={false}
      />

      <main className="max-w-6xl mx-auto px-4 py-12">
        <BlogFilters
          selectedCategory={selectedCategory}
          onCategoryChange={setSelectedCategory}
          viewMode={viewMode}
          onViewModeChange={setViewMode}
        />

        {filteredArticles.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No articles found in this category.</p>
          </div>
        ) : viewMode === "grid" ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredArticles.map((article) => (
              <ArticleCard key={article.id} article={article} />
            ))}
          </div>
        ) : (
          <div className="divide-y-0">
            {filteredArticles.map((article) => (
              <ArticleListItem key={article.id} article={article} />
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
