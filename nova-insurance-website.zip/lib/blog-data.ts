export interface BlogArticle {
  id: string
  slug: string
  title: string
  excerpt: string
  author: string
  date: string
  category: string
  image: string
  readTime: string
}

export const categories = ["All", "Safe Driving", "Insurance Tips", "New Drivers", "Seasonal", "Claims"]

export const blogArticles: BlogArticle[] = [
  {
    id: "1",
    slug: "drinking-in-the-new-year",
    title: "Drinking in the New Year",
    excerpt:
      "With the end of the year approaching, many of our calendars will be filled with holiday festivities, including ugly sweaters, food, gatherings, and adult beverages.",
    author: "Ben Ajayi",
    date: "December 28, 2024",
    category: "Seasonal",
    image: "/champagne-celebration-new-year-party.jpg",
    readTime: "5 min read",
  },
  {
    id: "2",
    slug: "keeping-your-cool-managing-stress-while-driving",
    title: "Keeping Your Cool; Managing Stress While Driving",
    excerpt:
      "Road rage is more common than you might think. Learn strategies to stay calm behind the wheel and avoid dangerous situations.",
    author: "Ben Ajayi",
    date: "December 15, 2024",
    category: "Safe Driving",
    image: "/stressed-driver-in-car-traffic.jpg",
    readTime: "4 min read",
  },
  {
    id: "3",
    slug: "affordable-insurance-for-new-drivers",
    title: "Affordable Insurance For New Drivers",
    excerpt:
      "New drivers often face higher car insurance costs due to their limited experience and increased accident risk. Learn how to find affordable coverage.",
    author: "Sarah Mitchell",
    date: "December 10, 2024",
    category: "New Drivers",
    image: "/young-woman-smiling-in-car-driver-seat.jpg",
    readTime: "6 min read",
  },
  {
    id: "4",
    slug: "understanding-your-auto-insurance-policy",
    title: "Understanding Your Auto Insurance Policy",
    excerpt:
      "Do you know what your auto insurance policy actually covers? We break down the key components so you can make informed decisions.",
    author: "Michael Chen",
    date: "December 5, 2024",
    category: "Insurance Tips",
    image: "/insurance-documents-paperwork-desk.jpg",
    readTime: "7 min read",
  },
  {
    id: "5",
    slug: "winter-driving-tips",
    title: "Winter Driving Tips to Keep You Safe",
    excerpt:
      "Ice, snow, and reduced visibility make winter driving challenging. Follow these tips to stay safe on the road this season.",
    author: "Jessica Torres",
    date: "November 28, 2024",
    category: "Seasonal",
    image: "/car-driving-on-snowy-winter-road.jpg",
    readTime: "5 min read",
  },
  {
    id: "6",
    slug: "how-to-file-an-insurance-claim",
    title: "How to File an Insurance Claim: A Step-by-Step Guide",
    excerpt:
      "Filing an insurance claim doesn't have to be stressful. Follow our simple guide to ensure a smooth claims process.",
    author: "Ben Ajayi",
    date: "November 20, 2024",
    category: "Claims",
    image: "/person-filling-insurance-claim-form.jpg",
    readTime: "8 min read",
  },
]
